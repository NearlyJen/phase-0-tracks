
class Dancer
  attr_reader :name
  attr_accessor :age

  def initialize(name, age)
    @name = name
    @age = age
    @partners_list = Array.new
  end

  def pirouette
    p '*twirls*'
  end

  def bow
    p '*bows*'
  end

  def queue_dance_with(partner)
    @partner = partner
    @partners_list.push(partner)
  end

  def card
    p @partners_list
  end

  def begin_next_dance
    p "Now dancing with #{@partners_list.shift}."
  end

  # method which will give the dancer a new randomly chosen tutu color
  def change_tutu
    tutu_options = ['red', 'orange', 'yellow', 'green', 'blue', 'purple']
    @tutu = tutu_options.sample
    p "Your tutu is now #{@tutu}. Pretty!"
  end
end


# driver code to test change_tutu method
# jen = Dancer.new('Jennifer', 33)
# jen.change_tutu
